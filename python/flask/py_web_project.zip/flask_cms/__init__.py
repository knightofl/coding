from  flask  import Flask, render_template, redirect, url_for, session, request

# 세션은 서버 메모리 저장(파일럿 수준), 서버쪽 디비에 저장, 
# 제 3의 서드 파트 모듈사용등을 고려
# 여기서는 서버 메모리 저장방식
from flask_cms.db.d8 import selectLogin

app = Flask(__name__)
# 세션키를 지정 (세션키는 향후 해쉬값을 활용하여 세팅)
app.secret_key = "skdhvldjdvosdcosdjcnksdcjk"

# 모든 요청의 전처리와 후처리를 할수 잇는 라이프 사이클 이벤트 핸들러 함수들이 존재 
#@app.before_first_request
# 요청을 카테고리 별로 나눠어서 처리하는 방식 BluePrint
# 디비를 고급화 처리, sqlalchemy+pymysql 식으로 브릿지 하여 ORM 처리 방식
# 혹은 풀링기법을 사용한 방식


@app.route('/')
def home():
    # 세션 체크
    # 세션이 없다면 -> login 보내버린다
    if 'uid' in session:
        return render_template('index.html', title='Flask CMS')
    else:
        return redirect( url_for('login') )

@app.route('/logout')
def logout():
    # 세션 제거
    if 'uid' in session:# 세션안에 uid라는 키가 존재하는다 =>세션이 있는가?
        session.pop('uid', None)
    if 'name' in session:# 세션안에 uid라는 키가 존재하는다 =>세션이 있는가?
        session.pop('name', None)
    return redirect( url_for('home') )

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html')
    else:
        uid = request.form.get('uid')
        upw = request.form['upw']
        if uid and upw: # 정상
            # 디비로 가서 쿼리(회원인지 체크) => python + database 프로그램
            row = selectLogin( uid, upw )
            if row:
                # 회원이라면 => 메인 서비스로 이동
                # 세션 생성
                session['uid']  = uid
                session['name'] = row['name']
                return redirect( url_for('home') )
            else:
                # 회원이 아니라면 -> 모라하고 => 돌려보낸다
                return render_template('error.html', errMsg='회원 아니다')
            
        else:# 비정상
            return render_template('error.html', errMsg='입력값이 부정확')

    
if __name__ == '__main__':
    app.run(host='0.0.0.0')