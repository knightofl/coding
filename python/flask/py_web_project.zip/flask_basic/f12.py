from flask import Flask, request, render_template, redirect, url_for, jsonify

#from d7 import selectLogin
# 상용 서버는 wsgi.py로부터 프로그램이 시작되므로 
# 패키지의 시작점이 test.db.db 이렇게 변경된다
# 따라서, 개발할때도 엔트리 포인트를 준비하여 구성하면 패키지 경로가 동일하게 된다
#from test.d8 import selectLogin, selectOil, updateOilStoreInfo
from test.db.d8 import selectLogin, selectOil, updateOilStoreInfo

app = Flask(__name__)

# API만 지원하는 url이고, 이것으로만 구성된 서버는 미들웨어 서버 
# 네이티브앱과 통신하는 모바일 서버가 이런 스타일
@app.route('/search', methods=['POST'])
def search():    
    # 검색어 획득 : request.form['keyword']
    keyword = request.form['keyword']
    if keyword.isnumeric():# 정수값
        return jsonify( selectOil(queryType=2, price=int(keyword) ) )
    else:# 일반 글자
        # 쿼리 수행 : selectOil(3, keyword=)
        # 결과를 json 반환 : jsonify()
        return jsonify(selectOil(queryType=3, keyword=keyword))

@app.route('/')
def home():
    # d7백업 d8에서 작업
    # 테이블명은 tbl_oil => 전체 조회 하는 함수 1개
    # 테이블명은 tbl_oil => 휘발유(gas)로 특정 가격 이하 주유소 정보 획득 함수 1개
    # 테이블명은 tbl_oil => 주유소명 (일부 단어가 포함되면 ok ) 검색 함수 1개
    return render_template('home.html', oils=selectOil() )

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html')
    else:
        uid = request.form.get('uid')
        upw = request.form['upw']
        if uid and upw: # 정상
            # 디비로 가서 쿼리(회원인지 체크) => python + database 프로그램
            row = selectLogin( uid, upw )
            if row:
                # 회원이라면 => 메인 서비스로 이동
                return redirect( url_for('home') )
            else:
                # 회원이 아니라면 -> 모라하고 => 돌려보낸다
                return render_template('error.html', errMsg='회원 아니다')
            
        else:# 비정상
            return render_template('error.html', errMsg='입력값이 부정확')

# 주유소별 상세 정보 보기
@app.route('/info/<int:id>', methods=['GET', 'POST'])
def info(id):
    if request.method == 'GET':
        # 파라미터 u를 획득
        # 파이썬의 3항 연산자를 만들어 보앗음
        isUpdate = True if request.args.get('u') else False
        print( isUpdate )
        return render_template('info.html', 
                        oilStoreInfo=selectOil(queryType=4, id=id), 
                        isUpdate=isUpdate )
    else:# 실제 수정 처리
        # 파라미터 획득
        gas = request.form.get('gas')
        # 값체크 부분은 생략
        # 디비 쿼리 수행(update) -> 리턴값은 영향을 받은 로의 수
        if updateOilStoreInfo( id, gas ):
            # 수행 결과를 받아서 성공하면(영향받은 row의 수가 1개이상)
            # 성공하면 -> 수정되었습니다 -> 메인페이지로 이동
            return render_template('error.html', errMsg='수정 성공', 
                                                 dst=url_for('home'))
        else:
            # 실패하면 -> 수정 실패 -> 해당 주유소 미리보기 이동
            return render_template('error.html', errMsg='수정 실패', 
                                                 dst=url_for('info', id=id))

if __name__ == '__main__':
    app.run(debug=True)
