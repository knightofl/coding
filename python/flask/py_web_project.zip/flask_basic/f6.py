# 동적 파라미터 
# ( url 주소에 데이터를 실어서 보낸다 )
# http 프로토콜상 헤더를 타고 전달됨
# 보안에 취약하니까, 중요하지 않은 데이터(노출되도상관없는) 사용
# 대표적인 케이스: 뉴스 기사(~/news/201811131113000000)
from flask import Flask

app = Flask(__name__)

# 동적 파라미터명을 연결된 함수의 인자로 전달해야 함수 내부로 
# 가져와서 사용할수 있다
# 동적 파리미터는 <동적파리미터명>
@app.route('/userinfo/<news_id>')
def userinfo( news_id ):
    # 문자열 더하기 => news_id가 문자열임
    return "<h2>hello flask2</h2>" + news_id

# 동적 파라미터에 타입 제한
# 지원타입으로는 int, float, path 가능
# int 타입으로 제한하는 동적 파라미터 => int가 아니면 404
@app.route('/add/<int:x>/<int:y>')
def add(x, y):
    # 문자열 포멧팅
    return " %d + %d = %d " % (x, y, x+y)

# path형 : 동적 파라미터를 자유롭게 n개 보내는 방법
@app.route('/free/<path:arg>')
def free( arg ):
    # 전달한 데이터를 각각 뽑아서 콘솔에 출력하시오
    print( arg.split('/') )
    for p in arg.split('/'):
        print( p )
    return arg


if __name__ == '__main__':
    app.run(debug=True)
