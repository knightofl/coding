# url뒤에 / 처리
# 간혹 url 정의할때 
# ~/pro
# ~/pro/
# 4번라인의 표현을 3라인과 동일하게 취급할것인가!!
from flask import Flask

app = Flask(__name__)

# 두개의 표현을 다 OK
# ~/pro  => ~/pro/
# ~/pro/ => ~/pro/
@app.route('/pro/')
def home():
    return "<h2>hello flask2</h2>"

if __name__ == '__main__':
    app.run(debug=True)
