-- 로그인 쿼리
select * from tbl_users where uid='centom' and upw='1234';

-- 전체 조회 하는 함수 1개
select * from tbl_oil;

-- 휘발유(gas)로 특정 가격 이하 주유소 정보 획득 함수 1
select * from tbl_oil where gas <= '1586';

-- 주유소명 (일부 단어가 포함되면 ok ) 검색 함수 1개
select * from tbl_oil where name like '%은마%';

-- 주유소 정보 업데이트
update tbl_oil set gas=1589 where id=1;








