-- --------------------------------------------------------
-- 호스트:                          127.0.0.1
-- 서버 버전:                        10.3.10-MariaDB - mariadb.org binary distribution
-- 서버 OS:                        Win64
-- HeidiSQL 버전:                  9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- 테이블 pythondb.tbl_oil 구조 내보내기
CREATE TABLE IF NOT EXISTS `tbl_oil` (
  `area` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `addr` varchar(50) DEFAULT NULL,
  `brand` varchar(50) DEFAULT NULL,
  `tel` varchar(50) DEFAULT NULL,
  `self` varchar(50) DEFAULT NULL,
  `gas_p` varchar(50) DEFAULT NULL,
  `gas` varchar(50) DEFAULT NULL,
  `gas_l` varchar(50) DEFAULT NULL,
  `gas_d` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 테이블 데이터 pythondb.tbl_oil:~0 rows (대략적) 내보내기
/*!40000 ALTER TABLE `tbl_oil` DISABLE KEYS */;
INSERT INTO `tbl_oil` (`area`, `name`, `addr`, `brand`, `tel`, `self`, `gas_p`, `gas`, `gas_l`, `gas_d`) VALUES
	('부산광역시', '은마석유경기장주유소', '부산 강서구 낙동북로 364 (대저1동)', 'GS칼텍스', '051-971-7956', 'Y', '0', '1588', '1368', '0'),
	('부산광역시', '(주)만은에너지 대사리주유소', '부산 강서구 낙동북로 65 (강동동)', 'GS칼텍스', '051-973-5999', 'Y', '0', '1588', '1388', '950');
/*!40000 ALTER TABLE `tbl_oil` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
