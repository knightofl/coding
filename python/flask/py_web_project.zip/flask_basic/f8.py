# 코드내에서 URL을 호출할때 직접 하드 코딩하지 않는다
# 오직 url은 라우트에서만 정의하고 나머지 참조는 url_for() 사용
# url_for('특정 url과 연결된 함수명을 기술')
from flask import Flask, url_for

app = Flask(__name__)

# url_for의 작동만 테스트 할것이므로 return은 필요없다
# 코드의 진행을 드냥 흘려 보내는 방법 pass
@app.route('/')
def home():pass

@app.route('/login')
def login2():pass

@app.route('/news/<id>')
def news2(id):
    pass

# url 요청 테스트
# with문 
# I/O 계열에서 주로 사용이 된다. 왜 => 개발자가 close를 자꾸 까먹는 경향이 있다
# 자동으로 닫아주면 좋겟다 => with ~
with app.test_request_context():
    print( '홈페이지의 URL은 =>', url_for('home') )
    print( '로그인페이지의 URL은 =>', url_for('login2') )
    print( '동적파리미터의 URL은 =>', url_for('news2', id='1234') )

if __name__ == '__main__':
    app.run(debug=True)
