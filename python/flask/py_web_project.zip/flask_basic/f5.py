# URL 추가하기
from flask import Flask

app = Flask(__name__)


@app.route('/')
def home():
    return "<h2>hello flask2</h2>"

# ~/login URL을 정의
# 데코레이션 함수
@app.route('/login')
def login():
    return 'login 페이지'


if __name__ == '__main__':
    app.run(debug=True)
else:
    print( '본 모듈은 단독으로 구동될때 정상 작동합니다.(모듈화 사용금지)' )  