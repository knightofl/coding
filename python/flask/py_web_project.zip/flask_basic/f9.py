# get, post 방식
# restful 처리
# ~/login : GET방식으로는  로그인 폼(html) 구성
# ~/login : POST방식으로는 로그인 처리 구성
from flask import Flask, request

app = Flask(__name__)

# 기본 라우트를 기술하면 -> get방식을 의미함
# 기본 GET방식 이외에 POST방식도 사용되게 처리
# 메소드 방식은 http의 헤더에 설정되서 요청(request)으로 전달된다
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return "get"
    else:
        return "post"
    #print( request.method )
    

if __name__ == '__main__':
    app.run(debug=True)
