flask 프로젝트 밑에 
/static 이라는 곳은 
정적 데이터가 존재하는 곳으로 
별도의 라우트없이 파일이 존재하는 것만으로 URL이 생성된다

- 파일 업로드 저장위치로 사용
- js, css, 이미지들을 저장하는 위치로도 사용
- 단, html 파일을 가급적 두지 않는다 -> templates

- url은
~/static/xx.xx