// html이 DOM tree가 구성되고 화면이 보이기 직전 상태
//$(document).ready( function(){} );
$(document).ready( ()=>{
    //alert('dom');
    // form태그의 submit 이벤트를 인터셉트 
    //$('css 셀렉터') 이런 표현법으로 요소를 찾는다
    // 현재 문서상에 존재하는 모든 form 요소
    $('form').on('submit', ( evt )=>{
        // 이벤트 무효화 시킴
        evt.preventDefault();
        
        // ajax 통신 수행
        console.log('ajax 검색');
        $.post({
            url:'/search',         // 서버 url
            data: $('form').serialize(),  // 전달 데이터 keyword=xxx&name=xxxx....
            dataType: 'json',      // 응답 타입
            success:( data )=>{
                console.log('응답 성공', data)
                // 검색어
                const word = $('input[name=keyword]').val()
                // 검색어 초기화
                $('#result b').empty();
                // 검색어 세팅                
                $('#result b').append( word  )
                // 검색창 초기화
                $('input[name=keyword]').val('')

                // 주유소 이름과 gas 가격만 표시
                $('#result ul').empty();
                $.each( data, (index, oil)=>{
                    //var html = '<li>'+oil.name+' : 휘발유 '+oil.gas+'원</li>'
                    var html = `<li>${oil.name} : 휘발유 ${oil.gas}원</li>`                    
                    //console.log( oil.name, oil.gas );
                    $('#result ul').append( html.replace( word, `<b>${word}</b>` ) )
                    // 링크를 생성하여 => 클릭이벤트를 생성하여 서브 페이지 이동 정의
                    // 아이디가 result인 요소의 자식/후손들 중에 ul
                    // 이런 ul의 직계 자식들중 li                    
                    // 의사 결정 셀렉터 : last(막내) 특성
                    $('#result ul>li:last').on('click', ()=>{
                        if ( confirm( `${oil.name}로 이동하시겠습니까` ) )
                        {
                            // 주유소 상세 페이지 이동
                            document.location.href='/info/'+oil.id
                        }
                        
                    });
                } );

            },  // 성공 응답
            error:( err )=>{
                console.log('응답 실패', err)
            }      // 실패 응답
        });

        // 이벤트 종료
        return false;
    });
} );