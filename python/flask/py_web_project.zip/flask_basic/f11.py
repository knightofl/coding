from flask import Flask, request, render_template
import pymysql as my

app = Flask(__name__)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html')
    else:
        uid = request.form.get('uid')
        upw = request.form['upw']
        if uid and upw: # 정상
            # 디비로 가서 쿼리(회원인지 체크) => python + database 프로그램
            row = selectLogin( uid, upw )
            if row:
                # 회원이라면 => 메인 서비스로 이동
                return '회원 이다'
            else:
                # 회원이 아니라면 -> 모라하고 => 돌려보낸다
                return '회원 아니다'
            
        else:# 비정상
            return render_template('error.html', errMsg='입력값이 부정확')

def selectLogin( uid, upw ):
    connection = None
    row        = None
    try:
        connection = my.connect(host='localhost',
                                user='root',
                                password='1234',
                                db='pythondb',
                                charset='utf8',
                                cursorclass=my.cursors.DictCursor)
        # 3. 쿼리 ==================================================    
        with connection.cursor() as cursor:
            sql = "select * from tbl_users where uid=%s and upw=%s;"
            cursor.execute( sql, (uid, upw) )        
            # 결과 세팅
            row = cursor.fetchone()            
        # 3. 쿼리 ==================================================
    except Exception as e:
        print( e )
        # 향후 확장성을 고려하여 예외 상황 발생시 None으로 초기화
        row        = None
    finally:
        if connection:
            connection.close()
            print('접속 해제 완료')
    return row

if __name__ == '__main__':
    app.run(debug=True)
