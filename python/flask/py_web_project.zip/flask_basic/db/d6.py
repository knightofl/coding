# sql문의 파라미터값을 외부로 뺀다
import pymysql as my

def selectLogin():
    connection = None
    try:
        connection = my.connect(host='localhost',
                                user='root',
                                password='1234',
                                db='pythondb',
                                charset='utf8',
                                cursorclass=my.cursors.DictCursor)
        # 3. 쿼리 ==================================================    
        with connection.cursor() as cursor:
            # 파라미터 전달시 '' 이 기호 주의 
            sql = "select * from tbl_users where uid=%s and upw=%s;"
            # 파라미터는 tuple 형태로 전달
            cursor.execute( sql, ("centom","1234") )        
            row = cursor.fetchone()
            print( '%s님 방갑습니다.' % row['name'] )    
        # 3. 쿼리 ==================================================
    except Exception as e:
        print( e )
    finally:
        if connection:
            connection.close()
            print('접속 해제 완료')

selectLogin()





