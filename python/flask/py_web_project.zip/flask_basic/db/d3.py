# select 쿼리 결과가 딕셔너릭 구조로 와야 한다. 
# 컬럼의 순서가 변경되도 컬럼명으로 데이터를 횓득하면 되니까 상관없다
import pymysql as my

connection = None
try:
    connection = my.connect(host='localhost',
                            user='root',
                            password='1234',
                            db='pythondb',
                            charset='utf8')
    # 3. 쿼리 ==================================================    
    with connection.cursor(my.cursors.DictCursor) as cursor:
        sql = "select * from tbl_users where uid='centom' and upw='1234';"
        cursor.execute( sql )        
        row = cursor.fetchone()
        print( row )
        print( '%s님 방갑습니다.' % row['name'] )    
    # 3. 쿼리 ==================================================
except Exception as e:
    print( e )
finally:
    if connection:
        connection.close()
        print('접속 해제 완료')







