# sql문의 파라미터값을 외부로 뺀다
import pymysql as my

def selectLogin( uid, upw ):
    connection = None
    row        = None
    try:
        connection = my.connect(host='localhost',
                                user='root',
                                password='1234',
                                db='pythondb',
                                charset='utf8',
                                cursorclass=my.cursors.DictCursor)
        # 3. 쿼리 ==================================================    
        with connection.cursor() as cursor:
            sql = "select * from tbl_users where uid=%s and upw=%s;"
            cursor.execute( sql, (uid, upw) )        
            # 결과 세팅
            row = cursor.fetchone()            
        # 3. 쿼리 ==================================================
    except Exception as e:
        print( e )
        # 향후 확장성을 고려하여 예외 상황 발생시 None으로 초기화
        row        = None
    finally:
        if connection:
            connection.close()
            print('접속 해제 완료')
    return row

# 모듀화 작업을 할때는 테스트 코드는 모두 아래 표현 밑으로 들어간다
print( __name__ )
if __name__ == '__main__':
    # 테스트용으로 작성한 코드
    print( selectLogin('centom','1234') )





