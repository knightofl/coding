# python에서 데이터베이스 접속 및 쿼리 처리 등
# 데이터베이스이 종류에 따라 모듈(제품)들이 달라진다
# mysql 계열은 pymysql를 사용해 보겟다 
# raw query로 쿼리 수행을 하는 방식
# 고급 방식으로는 sqlAlchemy를 사용하여 ORM으로 처리한다
# 설치
# pip install PyMySQL

# 1. 모듈가져오기
# as 별칭: 이름이 길때 재정의하듯이 사용
import pymysql as my

connection = None
try:
    # 2. 디비 접속
    connection = my.connect(host='localhost',
                            user='root',
                            password='1234',
                            db='pythondb',
                            charset='utf8')
    # 3. 쿼리
    print('쿼리 수행')                   
except Exception as e:
    print( e )
finally:
    # 4. 접속 해제
    if connection:
        connection.close()
        print('접속 해제 완료')







