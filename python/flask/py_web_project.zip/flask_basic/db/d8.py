# sql문의 파라미터값을 외부로 뺀다
import pymysql as my

# 상용 데이터베이스 HOST 정보
TEST_DB_Host    = 'localhost'
RELEASE_DB_Host = 'pythondb2.cythlhij08x7.ap-northeast-2.rds.amazonaws.com'
USE_DB_HOST     = RELEASE_DB_Host

# 주유 정보 조회 함수
def selectOil( queryType=1, price=0, keyword='', id=0 ):
    connection = None
    rows       = None
    try:
        connection = my.connect(host=USE_DB_HOST,
                                user='root',
                                password='12341234',
                                db='pythondb',
                                charset='utf8',
                                cursorclass=my.cursors.DictCursor)
        # 3. 쿼리 ==================================================    
        with connection.cursor() as cursor:
            if queryType == 1: # 전체 조회
                sql = "select * from tbl_oil order by gas asc;"
                cursor.execute( sql )    
            elif queryType == 2: # 특정 가격 이하 주유소 검색
                sql = "select * from tbl_oil where gas <= %s order by gas asc;"
                cursor.execute( sql, (price,) )    
            elif queryType == 4: # 특정 주유소 정보 다 보내기
                sql = "select * from tbl_oil where id=%s"
                cursor.execute( sql, (id,) )
            else: # 특정 이름을 가진 주유소 검색
                sql = "select * from tbl_oil where name like '%{0}%' order by gas asc;".format(keyword)
                cursor.execute( sql )            
            
            # 결과 세팅
            if queryType == 4:
                rows = cursor.fetchone()
            else:
                rows = cursor.fetchall()
        # 3. 쿼리 ==================================================
    except Exception as e:
        print( e )
        # 향후 확장성을 고려하여 예외 상황 발생시 None으로 초기화
        rows        = None
    finally:
        if connection:
            connection.close()
            #print('접속 해제 완료')
    return rows

def selectLogin( uid, upw ):
    connection = None
    row        = None
    try:
        connection = my.connect(host=USE_DB_HOST,
                                user='root',
                                password='12341234',
                                db='pythondb',
                                charset='utf8',
                                cursorclass=my.cursors.DictCursor)
        # 3. 쿼리 ==================================================    
        with connection.cursor() as cursor:
            print( uid, upw )
            sql = "select * from tbl_users where uid=%s and upw=%s;"
            cursor.execute( sql, (uid, upw) )        
            # 결과 세팅
            row = cursor.fetchone()            
        # 3. 쿼리 ==================================================
    except Exception as e:
        print( e )
        # 향후 확장성을 고려하여 예외 상황 발생시 None으로 초기화
        row        = None
    finally:
        if connection:
            connection.close()
            print('접속 해제 완료', row)
    return row

def updateOilStoreInfo( id, gas ):
    connection  = None
    affectedRow = 0
    try:
        connection = my.connect(host=USE_DB_HOST,
                                user='root',
                                password='12341234',
                                db='pythondb',
                                charset='utf8',                                
                                cursorclass=my.cursors.DictCursor)
        # 3. 쿼리 ==================================================    
        with connection.cursor() as cursor:
            sql = "update tbl_oil set gas=%s where id=%s;"
            cursor.execute( sql, (gas, id) )
        # 반영
        connection.commit()
        # 3. 쿼리 ==================================================
    except Exception as e:
        print( e )
    finally:
        affectedRow = connection.affected_rows()
        if connection:
            connection.close()
    return affectedRow

if __name__ == '__main__':    
    print( updateOilStoreInfo(1, 1600) )
    #print( selectLogin('centom','12341234') )
    #print( selectOil(queryType=1) )
    #print( selectOil(queryType=2, price=1586) )
    #print( selectOil(queryType=3, keyword='만은') )





