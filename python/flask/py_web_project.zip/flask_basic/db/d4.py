# select 쿼리 결과가 딕셔너릭 구조로 와야 한다. 
# 컬럼의 순서가 변경되도 컬럼명으로 데이터를 횓득하면 되니까 상관없다
import pymysql as my

connection = None
try:
    # 앞으로 열리는 모든 커서의 타입은 DictCursor이다
    # 쿼리 결과문은 항상 딕셔너리이다
    connection = my.connect(host='localhost',
                            user='root',
                            password='1234',
                            db='pythondb',
                            charset='utf8',
                            cursorclass=my.cursors.DictCursor)
    # 3. 쿼리 ==================================================    
    with connection.cursor() as cursor:
        sql = "select * from tbl_users where uid='centom' and upw='1234';"
        cursor.execute( sql )        
        row = cursor.fetchone()
        print( row )
        print( '%s님 방갑습니다.' % row['name'] )    
    # 3. 쿼리 ==================================================
except Exception as e:
    print( e )
finally:
    if connection:
        connection.close()
        print('접속 해제 완료')







