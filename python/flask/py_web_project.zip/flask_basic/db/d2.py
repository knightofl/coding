import pymysql as my

connection = None
try:
    connection = my.connect(host='localhost',
                            user='root',
                            password='1234',
                            db='pythondb',
                            charset='utf8')
    # 3. 쿼리 ==================================================
    print('쿼리 수행')                   
    # with문은 I/O 계열 사용시 자동으로 닫기 처리를 해준다
    # 쿼리 수행을 하기 위해서는 : 커서 획득을 해야 한다 : 
    # connection.cursor()
    # 커서 오픈
    #cursor = connection.cursor()
    with connection.cursor() as cursor:
        # 쿼리 수행
        sql = "select * from tbl_users where uid='centom' and upw='1234';"
        cursor.execute( sql )
        # 결과 패치
        row = cursor.fetchone()
        print( '%s님 방갑습니다.' % row[3] )
    # 3. 쿼리 ==================================================
except Exception as e:
    print( e )
finally:
    if connection:
        connection.close()
        print('접속 해제 완료')







