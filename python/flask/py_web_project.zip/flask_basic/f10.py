# restful을 이용한 로그인 처리
# html 처리 => render_template() => jinja2(신사) 엔진 사용
# 현재 py위치를 기준으로 해서 /templates/login.html 존재
from flask import Flask, request, render_template

app = Flask(__name__)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html')
    else:
        # 아이디, 비번 획득
        uid = request.form.get('uid')
        upw = request.form['upw']
        print( uid, upw )
        # 누락이 있으면(비정상 접근시) => 컷팅
        #if not uid or not upw: # 비정상
        #else:# 정상        
        if uid and upw: # 정상
            # 디비로 가서 쿼리(회원인지 체크)
            # 회원이라면 => 메인 서비스로 이동
            # 회원이 아니라면 -> 모라하고 => 돌려보낸다
            pass
        else:# 비정상
            # 경고 처리
            return render_template('error.html', 
                                   errMsg='입력값이 부정확')
            # return '''
            # <script>
            #     alert("입력값이 부정확합니다.");
            #     history.back();
            # </script>
            # '''
        #return "post %s %s" % (uid, upw)

if __name__ == '__main__':
    app.run(debug=True)
