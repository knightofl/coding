################################
# 파이썬 기본 - 문자열의 내장함중 문자열의 성격을 조사하는 함수
################################
a = "a"
b = "A"
c = '1'
d = '#'
e = '가'
print( a.isalpha(), a.isdecimal(), a.isdigit(), a.isalnum(), a.isnumeric() )
print( b.isalpha(), b.isdecimal(), b.isdigit(), b.isalnum(), b.isnumeric() )
print( c.isalpha(), c.isdecimal(), c.isdigit(), c.isalnum(), c.isnumeric() )
print( d.isalpha(), d.isdecimal(), d.isdigit(), d.isalnum(), d.isnumeric() )
print( e.isalpha(), e.isdecimal(), e.isdigit(), e.isalnum(), e.isnumeric() )
