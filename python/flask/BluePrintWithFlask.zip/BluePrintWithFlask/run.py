'''
Created on 2017. 11. 22.
@author: edu

웹 프로그램 시작점
'''
from service import create_app

# Flask 객체를 생성해서 환경 설정해서 반환
application = create_app()

# 구동
if __name__ == '__main__':
    print('서버 가동')
    application.run(host='0.0.0.0', port=3000, debug=True)