'''
Created on 2017. 11. 22.
@author: edu
DB 매니저 
ORM 방식으로 함수를 통해 쿼리가 수행되는 방식 활용
디비 연결, 테이블 생성 (없을시)
pip install sqlalchemy
'''
from sqlalchemy import create_engine
from sqlalchemy.orm import scoped_session, sessionmaker

class DBManager:
    # 맴버 변수
    __engine  = None
    __session = None
    # 생성자
    # 맴버 함수
    # siatic 처리
    @staticmethod
    def init(db_url, db_log_flag=True):
        # 엔진 생성
        DBManager.__engine  = create_engine(db_url, echo=db_log_flag)
        # 세션 생성
        DBManager.__session = scoped_session( sessionmaker(
            autocommit=False,
            autoflush=False,
            bind=DBManager.__engine
            ) )
        global dao
        dao = DBManager.__session
        print('db_url', db_url)   
        
    @staticmethod
    def init_db():
        # 테이블이 없으면 테이블 생성 => model이 필요 => 정의
        from service.model import user
        from service.model import Base
        
        # 테이블이 없을시 모든 테이블 생성
        Base.metadata.create_all( bind=DBManager.__engine )
        print('init_db')
    
dao = None    










