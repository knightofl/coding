'''
Created on 2017. 11. 22.
@author: edu
blueprint => /url을 계열별로 묶을 수 있다
'''
from flask import Blueprint

# 전체 프로젝의 View 카테고리가 10개군으로 나눈다면,
# 블루프린트를 10개의 계열로 만들어서 각각 등록 
# 개별 프린트를 이용하여 라우트 하면 API 리스트가 완성된다

# /login/~
blueprint       = Blueprint('loginproc', 
                      __name__,
                      template_folder='templates',
                      static_folder='static' )

# /main/~
blueprintMain   = Blueprint('mainproc', 
                      __name__,
                      template_folder='templates',
                      static_folder='static' )

print( blueprint )











