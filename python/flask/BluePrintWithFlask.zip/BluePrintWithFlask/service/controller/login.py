'''
Created on 2017. 11. 22.
@author: edu
로그인 관련 함수
path : /login/~
'''
# import
from flask import render_template, request
from service.app_blueprint import blueprint
from service.app_database import dao
from service.model.user import User

# 라우팅
@blueprint.route('/')
def login():    
    print('로그인')
    # 회원가입 insert
    #newUser = User('username', 'email', 'password')
    #dao.add( newUser )
    #dao.commit()    
    # 회원정보획득 select
    #user = dao.query(User).filter_by(username='username', password='password').first()
    #print( user )
    # 회원정보수정 update
    #user.email = 'a@a.com'
    #dao.commit()
    # 회원 삭제 delete
    #dao.delete(user)
    #dao.commit()
    return render_template('loginForm.html')

@blueprint.route('/view')
def view():
    return "hello view"   

# 종료 처리
@blueprint.teardown_request
def close_db_session(exception=None):
    try:
        dao.remove()
    except Exception as e:
        print( eval(e) )
