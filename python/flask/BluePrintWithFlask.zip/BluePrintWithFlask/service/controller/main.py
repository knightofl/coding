'''
Created on 2017. 11. 22.
@author: edu
로그인 관련 함수
path : /main/~
'''
# import
from flask import render_template, request
from service.app_blueprint import blueprintMain as m
from service.app_database import dao
from service.model.user import User

# 라우팅
@m.route('/')
def mainHome():
    return render_template('loginForm.html')

@m.route('/view')
def view():
    return "hello view"   

# 종료 처리
@m.teardown_request
def close_db_session(exception=None):
    try:
        dao.remove()
    except Exception as e:
        print( eval(e) )
