'''
Created on 2017. 11. 22.
@author: edu
model 밑에 py 하나는 테이블 한개와 매핑 시킨다. 
user 테이블과 매핑
'''
from sqlalchemy import Column, Integer, String  
from service.model import Base
from enum import unique


class User(Base):
    # 테이블명  ###################################################
    __tablename__ = 'user'
    # 컬럼명  #####################################################
    id       = Column(Integer, primary_key=True)
    username = Column(String(50), unique=True)
    email    = Column(String(50), unique=False)
    password = Column(String(50), unique=False)
    # 생성자 ######################################################
    # 컬럼값을 설정
    def __init__(self, username, email, password):
        self.username   = username
        self.email      = email
        self.password   = password
    # 맴버 함수  ###################################################
    # 객체가 들고 있는 값을 출력
    def __repr__(self):
        value = "<User %s %s>" % (self.username, self.email)
        print(value)
        return value












