'''
Created on 2017. 11. 22.
@author: edu
환경 변수 클레스 => 디비 정보등 서버 구동시 필요한 정보를 가지고 있다
'''
class WebConfig(object):
    DB_URL          = 'localhost'
    DB_USER         = 'root'
    DB_PWD          = '1234'
    DB_DATABASE     = 'pythonDB'
    DB_CHARSET      = 'utf8'
    DB_LOG_FLAG     = 'True'
