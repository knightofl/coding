# import ###################################################
from flask import Flask, render_template

# error page ###############################################
# 404
def not_found(error):
    return render_template('404.html', error=str(error)), 404
# 500
def server_error(error):
    return render_template('500.html', error=str(error)), 500

# flask create #############################################
def create_app(config_path='resource/config.cfg'):
    app = Flask(__name__)
    # 환경변수 로드 ###########################################
    # 파일에서 로드
    app.config.from_pyfile(config_path, silent=True)
    # 클레스에서 로드
    from service.app_config import WebConfig
    app.config.from_object(WebConfig)
    # 확인
    print_config(app.config.items())
    # 데이터베이스 연결 처리  ####################################
    from service.app_database import DBManager
    db_url = "mysql+pymysql://%s:%s@%s/%s?charset=%s" % (
        app.config['DB_USER'],
        app.config['DB_PWD'],
        app.config['DB_URL'],
        app.config['DB_DATABASE'],
        app.config['DB_CHARSET']
        )
    # 디비 연결 완료
    DBManager.init(db_url, eval(app.config['DB_LOG_FLAG']))
    # 디비 초기화
    DBManager.init_db()
    # 뷰 처리  ###############################################
    from service.controller import login, main
    from service.app_blueprint import blueprint, blueprintMain
    app.register_blueprint(blueprint, url_prefix='/login')
    app.register_blueprint(blueprintMain, url_prefix='/main')
     
    # 에러 등록 처리  ##########################################
    app.register_error_handler(404, not_found)
    app.register_error_handler(500, server_error)
    return app

# 세팅 확인 ###################################################
def print_config(config):
    print("*"*100)
    print(config)
    print("*"*100)
    for key, value in config:
        print("%s=%s" % (key, value) )
    












